//! Test-only bridge to the production WALK transition and real Rapier fixture.

use super::*;
use serde::{Deserialize, Serialize};
use std::{collections::HashSet, fs, path::PathBuf};

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct ReplayInput {
    schema: u32,
    profile: ReplayProfile,
    runs: Vec<ReplayRun>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct ReplayProfile {
    effective_jump_height_creation: f32,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct ReplayRun {
    id: String,
    initial_floor_height: f32,
    controller_dt_seconds: Vec<f32>,
}

#[derive(Serialize)]
struct ReplayOutput {
    schema: u32,
    model: &'static str,
    profile_height_consumed: bool,
    runs: Vec<PredictedRun>,
}

#[derive(Serialize)]
struct PredictedRun {
    id: String,
    heights: Vec<f32>,
}

fn predict(run: &ReplayRun, tuning: &MovementTuning) -> PredictedRun {
    let mut state = WalkState::default();
    let mut height = run.initial_floor_height;
    let mut supported = true;
    let mut heights = vec![height];
    for (index, &dt) in run.controller_dt_seconds.iter().enumerate() {
        integrate_walk(
            &mut state,
            &WalkIntent {
                jump_pressed: index == 0,
                ..default()
            },
            tuning,
            dt,
            supported,
        );
        height += state.vertical_velocity * dt;
        supported = height <= run.initial_floor_height && state.vertical_velocity <= 0.0;
        if supported {
            height = run.initial_floor_height;
        }
        heights.push(height);
    }
    PredictedRun {
        id: run.id.clone(),
        heights,
    }
}

fn path_from_env(name: &str) -> PathBuf {
    std::env::var_os(name)
        .map(PathBuf::from)
        .unwrap_or_else(|| panic!("set {name} to an explicit artifact path"))
}

#[test]
#[ignore = "artifact bridge, run through scripts/check_skyrim_jump_runtime.py"]
fn export_production_jump_replay() {
    let input: ReplayInput =
        serde_json::from_slice(&fs::read(path_from_env("MUDCRAB_JUMP_REPLAY_INPUT")).unwrap())
            .expect("schedule-only jump replay input");
    assert_eq!(input.schema, 1);
    assert!(input.profile.effective_jump_height_creation.is_finite());
    assert!(!input.runs.is_empty());
    let mut ids = HashSet::new();
    for run in &input.runs {
        assert!(!run.id.is_empty() && ids.insert(&run.id));
        assert!(run.initial_floor_height.is_finite());
        assert!(!run.controller_dt_seconds.is_empty());
        assert!(
            run.controller_dt_seconds
                .iter()
                .all(|dt| dt.is_finite() && *dt > 0.0 && *dt <= 0.25)
        );
    }
    // The baseline has no height input. Preserve its original 900/340 defaults.
    let tuning = MovementTuning::default();
    let output = ReplayOutput {
        schema: 1,
        model: "production_integrate_walk_with_recorded_native_dt_original_900_340",
        profile_height_consumed: false,
        runs: input.runs.iter().map(|run| predict(run, &tuning)).collect(),
    };
    fs::write(
        path_from_env("MUDCRAB_JUMP_REPLAY_OUTPUT"),
        serde_json::to_vec_pretty(&output).unwrap(),
    )
    .unwrap();
}

#[test]
#[ignore = "native first-step regression is expected to fail before issue 221 is implemented"]
fn native_first_launch_step() {
    // Direct parameter snapshots from the three original training launches.
    let jump_height = 78.28_f32;
    let native_acceleration = 686.614_2_f32;
    let dt = 1.0 / 60.0;
    let expected_delta = ((2.0 * native_acceleration * jump_height).sqrt()
        - native_acceleration * 1.35_f32 * dt)
        * dt;
    let predicted = predict(
        &ReplayRun {
            id: "native-first-launch-step".into(),
            initial_floor_height: 0.0,
            controller_dt_seconds: vec![dt],
        },
        &MovementTuning::default(),
    );
    assert!(
        (predicted.heights[1] - expected_delta).abs() <= 0.0001,
        "first resolved free-flight rise {} differs from native {expected_delta}",
        predicted.heights[1]
    );
}

#[derive(Resource, Default)]
struct JumpCapture {
    armed: bool,
    jump_next: bool,
    samples: Vec<ResolvedSample>,
}

#[derive(Clone, Serialize)]
struct ResolvedSample {
    position: [f32; 3],
    kcc_supported: bool,
    desired_translation: [f32; 3],
    effective_translation: [f32; 3],
    collision_count: usize,
}

fn press_jump_once(mut capture: ResMut<JumpCapture>, mut intent: ResMut<WalkIntent>) {
    if capture.armed {
        *intent = WalkIntent {
            jump_pressed: capture.jump_next,
            ..default()
        };
        capture.jump_next = false;
    }
}

fn record_after_writeback(
    mut capture: ResMut<JumpCapture>,
    player: Query<(&Transform, &KinematicCharacterControllerOutput), With<PlayerBody>>,
) {
    if capture.armed {
        let (body, output) = player.single().expect("fixture player with KCC output");
        capture.samples.push(ResolvedSample {
            position: body.translation.to_array(),
            kcc_supported: output.grounded,
            desired_translation: output.desired_translation.to_array(),
            effective_translation: output.effective_translation.to_array(),
            collision_count: output.collisions.len(),
        });
    }
}

#[test]
#[ignore = "real headless Bevy/Rapier capture, requires MUDCRAB_JUMP_HEADLESS_OUTPUT"]
fn export_headless_jump() {
    let mut app = headless::fixture_app_with(|app| {
        app.init_resource::<JumpCapture>()
            .add_systems(FixedUpdate, press_jump_once.before(walk_movement_system))
            .add_systems(
                FixedUpdate,
                record_after_writeback.after(PhysicsSet::Writeback),
            );
    });
    headless::place_player(&mut app, Vec3::new(0.0, 200.0, 500.0));
    for _ in 0..240 {
        app.update();
    }
    let mut query = app
        .world_mut()
        .query_filtered::<(&Transform, &KinematicCharacterControllerOutput), With<PlayerBody>>();
    let (body, output) = query.single(app.world()).unwrap();
    let rest = body.translation;
    assert!(output.grounded, "raw KCC support missing before jump");
    {
        let mut capture = app.world_mut().resource_mut::<JumpCapture>();
        capture.armed = true;
        capture.jump_next = true;
    }
    for _ in 0..180 {
        app.update();
    }
    let capture = app.world().resource::<JumpCapture>();
    let samples = &capture.samples;
    assert!(!samples.is_empty());
    assert!(
        samples
            .iter()
            .all(|sample| sample.position.iter().all(|v| v.is_finite()))
    );
    let apex_index = samples
        .iter()
        .enumerate()
        .max_by(|(_, a), (_, b)| a.position[1].total_cmp(&b.position[1]))
        .unwrap()
        .0;
    let landing_index = samples
        .iter()
        .enumerate()
        .skip(apex_index + 1)
        .find(|(_, sample)| sample.kcc_supported && (sample.position[1] - rest.y).abs() < 2.0)
        .map(|(index, _)| index)
        .expect("raw KCC landing after apex");
    assert!(samples[apex_index].position[1] - rest.y > 10.0);
    assert!(samples.iter().any(|sample| !sample.kcc_supported));
    assert!(samples.last().unwrap().kcc_supported);
    let report = serde_json::json!({
        "schema": 1,
        "surface": "production PhysicsFixturePlugin flat floor; raw post-Writeback Transform/KCC",
        "dt_seconds": PHYSICS_TIMESTEP,
        "rest_position": rest.to_array(),
        "first_delta_y": samples[0].position[1] - rest.y,
        "sampled_apex_rise": samples[apex_index].position[1] - rest.y,
        "apex_tick": apex_index + 1,
        "landing_tick": landing_index + 1,
        "landing_delta_y": samples[landing_index].position[1] - rest.y,
        "samples": samples,
    });
    fs::write(
        path_from_env("MUDCRAB_JUMP_HEADLESS_OUTPUT"),
        serde_json::to_vec_pretty(&report).unwrap(),
    )
    .unwrap();
}
